# Notebooks for the heavy workloads that are compute intensive
**STEP 1:** Run: `docker-composer up` and open your browser in `http://<public_ip>:8888`

**STEP 2:** Now you can run your notebook `http://localhost:8888` or `http://<public_ip>:8888`.

